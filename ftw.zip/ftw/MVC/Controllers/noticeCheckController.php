<?php
require_once('../Models/noticedb.php');


function notice_view(){
    return notice_Check();
}



?>