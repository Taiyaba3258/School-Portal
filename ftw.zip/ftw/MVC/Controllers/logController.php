<?php
header("location:../views/log.php");
?>